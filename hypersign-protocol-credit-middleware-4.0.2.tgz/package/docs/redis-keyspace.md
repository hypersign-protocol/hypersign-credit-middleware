# Redis keyspace

Version 4 uses a versioned base:

```text
<keyPrefix>:v2:{<redisHashTag>}
```

The hash tag keeps every Lua key in one Redis Cluster slot. Version `v2`
prevents legacy aggregate balances from being interpreted as plan state.

Wallet scope is derived from:

```text
tenantId, appType, appId, creditType
```

Each dimension records whether it is absent and URI-encodes its value. The
catalog ID is transport identity and is not part of wallet scope.

## Keys

| Purpose | Suffix | Type |
| --- | --- | --- |
| Cached aggregate | `balance:<scope>` | String integer |
| FIFO active plans | `plans:order:<scope>` | Sorted set (`grantedAt`, `planId`) |
| Original amount | `plans:amount:<scope>` | Hash (`planId -> integer`) |
| Available amount | `plans:remaining:<scope>` | Hash |
| Expiry | `plans:expires:<scope>` | Hash |
| Grant time | `plans:granted-at:<scope>` | Hash |
| Business reference | `plans:reference:<scope>` | Hash |
| Plan status | `plans:status:<scope>` | Hash |
| Expiration member | `plans:expiration-member:<scope>` | Hash |
| Global plan ownership | `plan-owner:<planId>` | Hash |
| Grant idempotency | `grant:<referenceId>` | Hash |
| Plan expiry index | `plan:expirations` | Sorted set |
| Reservation | `reservation:<reservationId>` | Hash |
| Request idempotency | `request:<scope>:<requestId>` | Hash |
| Reservation expiry | `reservation:expirations` | Sorted set |
| Transactional outbox | `events` | Stream |

Plan attribute hashes intentionally retain depleted/expired metadata. A plan
may still be referenced by an active reservation, so Redis TTL must not remove
it independently. Operational archival/cleanup must occur only after every
reservation referring to the plan has finalized and reconciliation retention
has elapsed.

`maxActivePlans` caps entries in the active FIFO sorted set. Depleted and
expired plans are removed from that set. `maxPlanAllocationsPerReservation`
limits one request's settlement fan-out.

## Plan state

Statuses:

```text
ACTIVE -> DEPLETED
ACTIVE -> EXPIRED
DEPLETED -> ACTIVE       rollback before expiry
DEPLETED -> EXPIRED      expiry while reserved
ACTIVE/DEPLETED -> REVOKED (reserved for an explicit future command)
```

A grant creates all plan attributes and the aggregate balance in one Lua call.
The same call appends `CREDIT_GRANTED`. Grant idempotency records are persistent;
they must not expire while a delayed BullMQ retry could reapply a payment.

## Reservation state

A reservation stores:

```text
reservationId, scopeId, appId, tenantId, appType, creditType,
requestId, total amount, aggregate balance after reservation,
status, leaseToken, createdAt, expiresAt, version,
settlementMode, operation, autoRecover, allocations JSON
```

Allocation JSON is an array of:

```json
{
  "planId": "plan-001",
  "amount": 10,
  "planBalanceAfter": 0
}
```

It is immutable. Settlement always uses this stored array.

Finalized reservation and request records receive `retentionMs`. Active records
have no TTL. Only `autoRecover=true` reservations are added to the reservation
expiry index.

## Expiration indexes

Plan-expiration members encode subject dimensions plus `planId` as JSON. This
lets a stateless recovery worker reconstruct the exact scoped hashes.

The SDK creates no timer. `CreditRecoveryService.runOnce()` processes bounded
batches from both expiration indexes. Reservation and plan transitions remain
atomic if several workers run concurrently.

## Events and BullMQ keys

The Stream key is:

```text
<keyPrefix>:v2:{<redisHashTag>}:events
```

Every financial state transition appends its event in the same Lua call. The
relay acknowledges a Stream entry only after all configured BullMQ queues accept
it. BullMQ itself creates keys such as:

```text
bull:credit.lifecycle:*
bull:credit.commands.<catalogId>:*
```

Use AOF, replication, tested backups, and `noeviction`. Evicting a plan or
reservation independently can make a later rollback unrecoverable.
